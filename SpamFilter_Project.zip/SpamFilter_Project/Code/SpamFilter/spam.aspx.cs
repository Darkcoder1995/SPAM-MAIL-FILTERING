﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;

public partial class adminpage : System.Web.UI.Page
{
    String userid = "";
    string cons = "Data Source=HP\\SQLEXPRESS;Initial Catalog=SpamFilter;Integrated Security=True";
  
    protected void Page_Load(object sender, EventArgs e)
    {
       userid = Session["userid"].ToString();
       Label2.Text = userid;
       /* Label3.Text = get_amount(userid);
        Label4.Text = get_acc_no(userid);
        Session["myaccno"] = Label4.Text;*/
        BindGrid();
    }
    public string get_count()
    {
        int count = 0;
        string id = "M";
        using (SqlConnection con = new SqlConnection(cons))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select distinct(count(mail_id)) from mail_inbox", con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    count= Convert.ToInt32(dr[0].ToString());

                }

                count = count + 1;
            }
            id = id + Convert.ToString(count);
            con.Close();
        }

        return id;
    }
    protected void btn_update_Click(object sender, EventArgs e)
    {
        string mailid = get_count();
        string uname = Session["userid"].ToString()+"@zmail.com";
        string receiver_mail = TextBox1.Text;
        string sub = TextBox2.Text;
        string body = TextBox3.Text;
        string s_type = "Sentmail";
        string s_status = "read";
        string r_status = "unread";
        string r_type = "inbox";
        string date = DateTime.Now.ToString();
        using (SqlConnection con = new SqlConnection(cons))
        {
            con.Open();
            string str = "insert into mail_inbox values('"+mailid+"','"+uname+"','"+s_type+"','"+receiver_mail+"','"+sub+"','"+body+"','"+date+"','"+s_status+"')";
            SqlCommand cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            string str1 = "insert into mail_inbox values('" + mailid + "','" + receiver_mail + "','" + r_type + "','" + uname + "','" + sub + "','" + body + "','" + date + "','" + r_status + "')";
            SqlCommand cmd1 = new SqlCommand(str1, con);
            int i=cmd1.ExecuteNonQuery();
            if (i > 0)
            {
                ///Mail Sent
            }
            else
            {
                ///Mail id not found or not sent
            }
            con.Close();
            
        }
    }
    private void BindGrid()
    {
        string user=Session["userid"].ToString()+"@zmail.com";
        using (SqlConnection con = new SqlConnection(cons))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT * FROM mail_inbox where uname='"+user+"'and type='spam' ", con))
            {
                cmd.CommandType = CommandType.Text;
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    using (DataTable dt = new DataTable())
                    {
                        sda.Fill(dt);

                        //Set AutoGenerateColumns False
                        // GridView1.AutoGenerateColumns = false;
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }
                }
            }
        }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        foreach (GridViewRow row in GridView1.Rows)
        {
            if (row.RowIndex == GridView1.SelectedIndex)
            {
                string vcode = GridView1.DataKeys[row.RowIndex].Value.ToString();

                row.BackColor = ColorTranslator.FromHtml("#A1DCF2");
                row.ToolTip = string.Empty;
                ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", "alert('" + vcode + "');", true);

                Session["mid"] = vcode;
                Session["type"] = "spam";
                Response.Redirect("mailreader.aspx");

            }
            else
            {
                row.BackColor = ColorTranslator.FromHtml("#FFFFFF");
                row.ToolTip = "Click to select this row.";
            }
        }
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(GridView1, "Select$" + e.Row.RowIndex);
            e.Row.ToolTip = "Click to select this row.";
        }
    }
}