﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Login : System.Web.UI.Page
{
    String user_id = "";
    string cons = "Data Source=HP\\SQLEXPRESS;Initial Catalog=SpamFilter;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        //user_id = "1617" + get_count().PadLeft(3, '0'); ;
    }
    public int check_user()
    {
        String user = TextBox1.Text + "@zmail.com";
        int count = 0;
        using (SqlConnection con = new SqlConnection(cons))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from register where uname like '%"+user+"%'", con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {

                count = 1;


            }
          
            con.Close();
        }
        return count;

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (check_user() == 0)
        {
            String user = TextBox1.Text + "@zmail.com";
            if (TextBox2.Text == TextBox5.Text)
            {
                if (DropDownList1.SelectedItem.Text != "Select")
                {
                    using (SqlConnection con = new SqlConnection(cons))
                    {
                        con.Open();
                        SqlCommand cmd2 = new SqlCommand("insert into settings values('" + user + "','False')", con);
                        cmd2.ExecuteNonQuery();
                        SqlCommand cmd1 = new SqlCommand("insert into register values('" + user + "','" + TextBox2.Text + "','" + DropDownList1.SelectedItem.Text + "','" + TextBox3.Text + "','Active')", con);
                        int i = cmd1.ExecuteNonQuery();
                        if (i > 0)
                        {
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect",
                            "alert('" + user_id + " Successfully Created.....'); window.location='" +
                            Request.ApplicationPath + "\\Login.aspx';", true);

                            //Label1.Text = user_id + " Successfully Created";
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect",
                            "alert('Registration UnSuccessful'); window.location='" +
                             Request.ApplicationPath + "\\signup.aspx';", true);
                            //Label1.Text = "Error while Registering";
                        }

                        con.Close();
                    }
                }
            }
            else
            {
                /// client script password not matched
                //ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", "Password Not Matched");
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Password Not Matched');", true);
            }
        }
        else
         {
             //// client script user already exists
             //ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", "Username already exists");
             ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Username Already Exists');", true);
         }
     

    }
   
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
}