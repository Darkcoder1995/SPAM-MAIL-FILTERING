﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text.RegularExpressions;
using System.IO;

/// <summary>
/// Summary description for spamfilter
/// </summary>
public class spamfilter
{
	public spamfilter()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public bool url_filter(String mail_id)
    {
        bool result=false;
        if (EvaluateIsValid(mail_id))
        {
            result = true;
        }
    
        return result;

    }
    public bool symbol_filter(String str)
    {
        bool res = false;
        String[] sym = {"@","rs","$","%","#","&","+","_","(",")","[","]","{","}","/","."};

        for (int i = 0; i < sym.Length; i++)
        {
            if (str.Contains(sym[i]))
            {
                res = true;
            }
        }
        return res;
    }
    public bool word_filter(String sub)
    {
        bool stats=false;
        StreamReader reader = new StreamReader(@"D:\SpamFilter_Project\Stop_List.txt");
        do
        {
            string textLine = reader.ReadLine();
            //stats = sub;
            if (sub.Contains(textLine))
            {
                stats = true;
            }

        } while (reader.Peek() != -1);
        reader.Close();
        return stats;
    }

    protected bool EvaluateIsValid(String val)
    {
        string pattern = @"^[a-z][a-z|0-9|]*([_][a-z|0-9]+)*([.][a-z|0-9]+([_][a-z|0-9]+)*)?@[a-z][a-z|0-9|]*\.([a-z][a-z|0-9]*(\.[a-z][a-z|0-9]*)?)$";
        Match match = Regex.Match(val.Trim(), pattern, RegexOptions.IgnoreCase);

        if (match.Success)
            return true;
        else
            return false;
    }
}