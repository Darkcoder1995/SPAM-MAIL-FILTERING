﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;

public partial class adminpage : System.Web.UI.Page
{
    String userid = "";
    String mid = "";
    String type = "";
    String alert = "False";
    string cons = "Data Source=HP\\SQLEXPRESS;Initial Catalog=SpamFilter;Integrated Security=True";
  
    protected void Page_Load(object sender, EventArgs e)
    {
       userid = Session["userid"].ToString();
      // mid = Session["mid"].ToString();
       Label2.Text = userid;
     
    }
    public void update_status(String mid,String type)
    {
        using (SqlConnection con = new SqlConnection(cons))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("update mail_inbox set status='read' where mail_id='" + mid + "' and type='" + type + "' and status='unread'", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

    }
   
    public string get_count()
    {
        int count = 0;
        string id = "M";
        using (SqlConnection con = new SqlConnection(cons))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select distinct(count(mail_id)) from mail_inbox", con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    count= Convert.ToInt32(dr[0].ToString());

                }

                count = count + 1;
            }
            id = id + Convert.ToString(count);
            con.Close();
        }

        return id;
    }
    protected void btn_update_Click(object sender, EventArgs e)
    {
        string mailid = get_count();
        string uname = Session["userid"].ToString()+"@zmail.com";
        string receiver_mail = TextBox1.Text;
        string sub = TextBox2.Text;
        string body = TextBox3.Text;
        string s_type = "Sentmail";
        string s_status = "read";
        string r_status = "unread";
        string r_type = "inbox";
        string date = DateTime.Now.ToString();
        using (SqlConnection con = new SqlConnection(cons))
        {
            con.Open();
            string str = "insert into mail_inbox values('"+mailid+"','"+uname+"','"+s_type+"','"+receiver_mail+"','"+sub+"','"+body+"','"+date+"','"+s_status+"')";
            SqlCommand cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            string str1 = "insert into mail_inbox values('" + mailid + "','" + receiver_mail + "','" + r_type + "','" + uname + "','" + sub + "','" + body + "','" + date + "','" + r_status + "')";
            SqlCommand cmd1 = new SqlCommand(str1, con);
            int i=cmd1.ExecuteNonQuery();
            if (i > 0)
            {
                ///Mail Sent
            }
            else
            {
                ///Mail id not found or not sent
            }
            con.Close();
            
        }
    }
    private void BindGrid()
    {
        string user=Session["userid"].ToString()+"@zmail.com";
        using (SqlConnection con = new SqlConnection(cons))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT * FROM mail_inbox where uname='"+user+"' and type='inbox' ", con))
            {
                cmd.CommandType = CommandType.Text;
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    using (DataTable dt = new DataTable())
                    {
                        sda.Fill(dt);

                        //Set AutoGenerateColumns False
                        // GridView1.AutoGenerateColumns = false;
                        
                    }
                }
            }
        }
    }


    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
        RadioButton2.Checked = false;
        alert = "True";
    }
    protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
    {
        RadioButton1.Checked = false;
        alert = "False";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
        if (RadioButton1.Checked == true)
        {
            alert = "True";
            string user = Session["userid"].ToString() + "@zmail.com";
            using (SqlConnection con = new SqlConnection(cons))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("update settings set alert='" + alert + "' where uname='" + user + "'", con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
        else if(RadioButton2.Checked==true)
        {
            String alert = "False";
            string user = Session["userid"].ToString() + "@zmail.com";
            using (SqlConnection con = new SqlConnection(cons))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("update settings set alert='" + alert + "' where uname='" + user + "'", con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
        ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect", "alert('Settings Updated'); window.location='" +
                        Request.ApplicationPath + "\\inbox.aspx';", true);
    }
}