﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Drawing;
public partial class Login : System.Web.UI.Page
{
    
    string cons = "Data Source=HP\\SQLEXPRESS;Initial Catalog=SpamFilter;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        /*if (!IsPostBack)
        {
            create_control1();
        }*/
    }

    protected void Page_PreInit(object sender, EventArgs e)
    {
        List<string> keys = Request.Form.AllKeys.Where(key => key.Contains("textbox")).ToList();
        int i = 1;
        foreach (string key in keys)
        {
            this.create_control();
           // this.create_control1();
            i++;
        }
    }
    public int get_textbox()
    {

        string message = "";
        TextBox tb = (TextBox)Panel1.FindControl("textbox");
        if(tb!=null)
        {
            message += tb.ID + ": " + tb.Text + "\\n";
            return 1;
        }
       // ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", "alert('" + message + "');", true);
        return 0;
    }
 
    protected void Button1_Click(object sender, EventArgs e)
    {
            String pass = "";


            if (get_textbox() > 0)
            {
                TextBox tb = (TextBox)Panel1.FindControl("textbox");
                // RadioButton im = (RadioButton)Panel1.FindControl("radio1");
                //ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", "alert('"+tb.Text+"');", true);
                //int check = get_status();
                if (TextBox1.Text != "" && tb.Text != "")
                {

                    String user = TextBox1.Text + "@zmail.com";
                    using (SqlConnection con = new SqlConnection(cons))
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("select * from register where uname='" + user + "' and pass='" + tb.Text + "'", con);
                        SqlDataReader dr;
                        dr = cmd.ExecuteReader();

                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                pass = dr[0].ToString();

                            }

                            ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect", "alert('Login Successful'); window.location='" +
                            Request.ApplicationPath + "\\inbox.aspx';", true);
                            Session["userid"] = TextBox1.Text;

                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect", "alert('Login Unsuccessful'); window.location='" +
                            Request.ApplicationPath + "\\Login.aspx';", true);
                        }
                        con.Close();

                    }

                }
            }
            else
            {
                if (TextBox1.Text != "")
                {


                    String user = TextBox1.Text + "@zmail.com";
                    ////get settings option
                    using (SqlConnection con = new SqlConnection(cons))
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("select Pass from register where uname='" + user + "' and Status='Active'", con);
                        SqlDataReader dr;
                        dr = cmd.ExecuteReader();

                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                pass = dr[0].ToString();

                            }
                            create_control();

                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect",
        "alert('User Id Not Exists'); window.location='" +
        Request.ApplicationPath + "\\Login.aspx';", true);
                        }
                        con.Close();
                    }
                    // get_status();

                }









            }
            
    

     
    }
   
    public void create_control()
    {
        System.Web.UI.HtmlControls.HtmlGenericControl createDiv =
 new System.Web.UI.HtmlControls.HtmlGenericControl("div");
        createDiv.ID = "createDiv";

        // Panel1.Controls.Add(createDiv);
        System.Web.UI.HtmlControls.HtmlGenericControl createDiv1 =
   new System.Web.UI.HtmlControls.HtmlGenericControl("div");
        createDiv1.ID = "createDiv1";
        createDiv1.InnerHtml = " Password ";
        createDiv.Controls.Add(createDiv1);
        
        TextBox text = new TextBox();
        text.ID = "textbox";
        text.TextMode = TextBoxMode.Password;
        text.CssClass = "form-control";

        createDiv.Controls.Add(text);

        // Panel1.Controls.Add(text);
        Panel1.Controls.Add(createDiv);
        HtmlControl control = FindControl("createDiv") as HtmlControl;
        control.Attributes["class"] = "control";
        HtmlControl control1 = FindControl("createDiv1") as HtmlControl;
        control1.Attributes["class"] = "label";
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }


    protected void radio_CheckedChanged(object sender, EventArgs e)
    {

        ClientScript.RegisterClientScriptBlock(this.GetType(), "radio1",

       "<script type = 'text/javascript'>alert('RadioButton Clicked');</script>");

    }

}